/* global define, jQuery */
define( [], function () {
	'use strict';
	return jQuery;
} );