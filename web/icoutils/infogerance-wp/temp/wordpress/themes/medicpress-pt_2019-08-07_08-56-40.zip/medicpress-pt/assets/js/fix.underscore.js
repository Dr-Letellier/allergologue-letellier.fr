/*global define, _*/
define( [], function () {
	'use strict';
	return _;
} );